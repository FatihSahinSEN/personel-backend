<?php
namespace App\Controllers;

use App\Controllers\BaseController;

class Api extends BaseController {

    public function index() {
        echo "Rest API Service";
    }
}